print("vida")
int x = 9;
if (x<4):
    {
    print("vida é bela")    
    }